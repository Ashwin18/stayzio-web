<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-sliders-h" style="color:var(--red);margin-right:.4rem;font-size:.9rem;"></i>
            {{ __('Filters') }}</h3>
        <button class="clear-all" type="button" onclick="clearFilters()">{{ __('Clear All') }}</button>
    </div>

    <div class="filter-section">
        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Stay Duration') }} <i class="fas fa-chevron-down"></i></div>
        <div class="chip-group">
            <span class="chip {{ request('hour') == '' ? 'selected' : '' }}" onclick="selectHourChip(this, '')">{{ __('All') }}</span>
            @foreach($bookingHours as $bookingHour)
                <span class="chip {{ request('hour') == $bookingHour->hour ? 'selected' : '' }}" onclick="selectHourChip(this, '{{ $bookingHour->id }}')">
                    {{ $bookingHour->hour }} {{ __('Hours') }}
                </span>
            @endforeach
        </div>
        <input type="hidden" name="hour" id="filter_hour" value="{{ request('hour') }}">
    </div>
    
    <div class="filter-section">
        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Area / Locality') }} <i class="fas fa-chevron-down"></i></div>
        <div class="chip-group">
            @foreach($locations as $location)
                <span class="chip {{ request('location_val') == $location->id ? 'selected' : '' }}" onclick="selectLocationChip(this, '{{ $location->id }}')">
                    {{ $location->name }}
                </span>
            @endforeach
        </div>
        <input type="hidden" name="location_val" id="filter_location_val" value="{{ request('location_val') }}">
    </div>

    <div class="filter-section">
        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Price Range') }} <i class="fas fa-chevron-down"></i></div>
        <div class="price-range-wrap">
            <div class="price-labels">
                <span>₹<span id="priceMin">{{ request('min_price', 500) }}</span></span>
                <span>₹<span id="priceMax">{{ number_format(request('max_price', 5000)) }}</span></span>
            </div>
            <input type="hidden" name="min_price" value="{{ request('min_price', 500) }}">
            <input type="range" name="max_price" min="500" max="10000" value="{{ request('max_price', 5000) }}" step="100"
                oninput="document.getElementById('priceMax').textContent = Number(this.value).toLocaleString('en-IN')"
                onchange="applySidebarFilters()"
                style="width:100%; margin-bottom:.4rem;">
        </div>
    </div>

    <div class="filter-section">
        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Guest Type') }} <i class="fas fa-chevron-down"></i></div>
        <div class="check-list">
            @php
                $selectedCategories = explode(',', request('category', ''));
            @endphp
            @foreach($categories as $category)
                <label class="check-item">
                    <input type="checkbox" class="category-checkbox" value="{{ $category->slug }}" {{ in_array($category->slug, $selectedCategories) ? 'checked' : '' }} onchange="updateCategories()">
                    <label>{{ $category->name }}</label>
                    @if(isset($category->rooms_count))
                        <span class="count">{{ $category->rooms_count }}</span>
                    @endif
                </label>
            @endforeach
        </div>
        <input type="hidden" name="category" id="category" value="{{ request('category') }}">
    </div>

    <div class="filter-section">
        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Star Rating') }} <i class="fas fa-chevron-down"></i></div>
        <div class="check-list">
            @for($i = 5; $i >= 1; $i--)
                <label class="check-item">
                    <input type="radio" name="ratings" value="{{ $i }}" {{ request('ratings') == $i ? 'checked' : '' }} onchange="applySidebarFilters()">
                    <label><span style="color:#f59e0b;">{!! str_repeat('★', $i) !!}</span> {{ $i }} {{ __('Star') }}</label>
                </label>
            @endfor
        </div>
    </div>

    <div class="filter-section">
    {{-- Couple Friendly Filter --}}
    <div class="filter-section">
        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Guest Type') }} <i class="fas fa-chevron-down"></i></div>
        <div class="check-list">
            <label class="check-item" style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:6px 0">
                <input type="checkbox" id="couple_friendly_check"
                    onchange="applyCoupleFilter(this)"
                    {{ request('couple_friendly') == 1 ? 'checked' : '' }}>
                <span style="display:flex;align-items:center;gap:6px;font-size:13px;font-weight:500;color:#111">
                    <i class="fas fa-heart" style="color:#e31e24;font-size:11px"></i>
                    Couple Friendly
                </span>
            </label>
            <label class="check-item" style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:6px 0">
                <input type="checkbox" id="family_check" disabled>
                <span style="font-size:13px;color:#6b7280">Family Friendly</span>
            </label>
        </div>
        <input type="hidden" name="couple_friendly" id="filter_couple_friendly" value="{{ request('couple_friendly', '') }}">
    </div>

        <div class="filter-title" onclick="toggleFilter(this)">{{ __('Amenities') }} <i class="fas fa-chevron-down"></i></div>
        <div class="check-list">
            @php
                $selectedAmenities = explode(',', request('amenitie', ''));
            @endphp
            @foreach($amenities as $amenity)
                <label class="check-item">
                    <input type="checkbox" class="amenity-checkbox" value="{{ $amenity->id }}" {{ in_array($amenity->id, $selectedAmenities) ? 'checked' : '' }} onchange="updateAmenities()">
                    <label>
                        @if(!empty($amenity->icon))
                            <i class="{{ $amenity->icon }}" style="color:var(--red);margin-right:.3rem;font-size:.72rem;"></i>
                        @endif
                        {{ $amenity->title }}
                    </label>
                </label>
            @endforeach
        </div>
        <input type="hidden" name="amenitie" id="amenitie" value="{{ request('amenitie') }}">
    </div>

    <div class="filter-section mt-3">
        <button type="button" onclick="applySidebarFilters()" class="btn-book w-100">
            {{ __('Apply Filters') }}
        </button>
    </div>
</aside>

<script>
    // Accordion visibility toggle logic
    function toggleFilter(element) {
        const contentBlock = element.nextElementSibling;
        const toggleIcon = element.querySelector('i');
        if (contentBlock.style.display === "none") {
            contentBlock.style.display = "";
            toggleIcon.className = "fas fa-chevron-down";
        } else {
            contentBlock.style.display = "none";
            toggleIcon.className = "fas fa-chevron-right";
        }
    }

    // Chip click management for Stay Duration
    function selectHourChip(element, val) {
        const parentGroup = element.parentElement;
        parentGroup.querySelectorAll('.chip').forEach(chip => chip.classList.remove('selected'));
        element.classList.add('selected');
        document.getElementById('filter_hour').value = val;
        applySidebarFilters(); // Auto-apply filters on selection
    }

    // Chip click management for Area / Locality
    function selectLocationChip(element, val) {
        const parentGroup = element.parentElement;
        const isAlreadySelected = element.classList.contains('selected');
        
        parentGroup.querySelectorAll('.chip').forEach(chip => chip.classList.remove('selected'));
        
        if (isAlreadySelected) {
            document.getElementById('filter_location_val').value = '';
        } else {
            element.classList.add('selected');
            document.getElementById('filter_location_val').value = val;
        }
        applySidebarFilters(); // Auto-apply filters on selection
    }

    // Multi-select serialization logic for Guest Type Category items
    function updateCategories() {
        let compiledCategories = [];
        document.querySelectorAll('.category-checkbox:checked').forEach(function(item) {
            compiledCategories.push(item.value);
        });
        document.getElementById('category').value = compiledCategories.join(',');
        applySidebarFilters(); // Auto-apply filters after updating state
    }

    // Multi-select serialization logic for Amenity checkboxes
    function updateAmenities() {
        let compiledAmenities = [];
        document.querySelectorAll('.input-checkbox:checked, .amenity-checkbox:checked').forEach(function(item) {
            compiledAmenities.push(item.value);
        });
        document.getElementById('amenitie').value = compiledAmenities.join(',');
        applySidebarFilters(); // Auto-apply filters after updating state
    }

    // Clean structural URL parameters processing factory
    function applySidebarFilters() {
        let currentUrlParams = new URLSearchParams(window.location.search);

        // 1. Map single tracking parameters
        currentUrlParams.set('hour', document.getElementById('filter_hour').value);
        currentUrlParams.set('min_price', '500');
        currentUrlParams.set('max_price', document.querySelector('input[name="max_price"]').value);
        currentUrlParams.set('category', document.getElementById('category').value);
        currentUrlParams.set('amenitie', document.getElementById('amenitie').value);
        currentUrlParams.set('city', document.getElementById('filter_location_val').value);
        // Couple friendly
        var cfVal = document.getElementById('filter_couple_friendly').value;
        if (cfVal) { currentUrlParams.set('couple_friendly', cfVal); } else { currentUrlParams.delete('couple_friendly'); }

        // 2. Map chosen active radio selection nodes
        const selectedRating = document.querySelector('input[name="ratings"]:checked');
        if (selectedRating) {
            currentUrlParams.set('ratings', selectedRating.value);
        } else {
            currentUrlParams.delete('ratings');
        }

        // 3. Map complex multi-item tracking sequences (Payment Checkboxes)
        currentUrlParams.delete('payment_mode[]'); 
        document.querySelectorAll('input[name="payment_mode[]"]:checked').forEach(item => {
            currentUrlParams.append('payment_mode[]', item.value);
        });

        // Reset pagination indexing counters safely back to index page 1
        currentUrlParams.delete('page');

        // Execute system-wide redirect
        window.location.href = "{{ route('frontend.rooms') }}?" + currentUrlParams.toString();
    }

    function applyCoupleFilter(checkbox) {
        document.getElementById('filter_couple_friendly').value = checkbox.checked ? 1 : '';
        applySidebarFilters();
    }

    // Flush and reset URL structure parameters
    function clearFilters() {
        window.location.href = "{{ route('frontend.rooms') }}";
    }
</script>