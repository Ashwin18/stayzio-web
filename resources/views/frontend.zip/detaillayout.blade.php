<!DOCTYPE html>
<html lang="zxx" dir="{{ $currentLanguageInfo->direction == 1 ? 'rtl' : '' }}">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="author" content="KreativDev">
  <meta name="keywords" content="@yield('metaKeywords')">
  <meta name="description" content="@yield('metaDescription')">
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <meta property="og:title" content="@yield('ogTitle')">
  {{-- title --}}
  <title>@yield('pageHeading') {{ '| ' . $websiteInfo->website_title }}</title>
  {{-- fav icon --}}
  <link class="shortcut icon" type="image/png" href="{{ asset('assets/img/' . $websiteInfo->favicon) }}">
  <link class="apple-touch-icon" href="{{ asset('assets/img/' . $websiteInfo->favicon) }}">
  @includeIf('frontend.partials.styles')
</head>
<body>
    
  <div id="stayzio-loader" class="stayzio-loader" aria-label="Loading StayZio">
  <div class="stayzio-loader-card">
    <img src="{{ asset('stayzio/images/stayzio-logo.png') }}" alt="StayZio Logo">
    <div class="stayzio-loader-name">Stay<span>Zio</span></div>
    <div class="stayzio-loader-line"><span></span></div>
  </div>
</div>

    <header class="topbar">
        <div class="topbar-inner">
            <button class="site-hamburger" type="button" aria-label="Open menu" onclick="toggleSiteMenu()"><i class="fas fa-bars"></i></button>
            <a href="{{ url('/') }}" class="brand stayzio-main-brand"><img src="{{ asset('stayzio/images/stayzio-logo.png') }}" alt="StayZio Logo" class="stayzio-brand-logo"><span class="stayzio-brand-text">Stay<span>Zio</span></span></a>
            
            <form action="{{ route('frontend.rooms') }}" method="GET" class="search-strip">
    <div class="ss-item">
        <i class="fas fa-map-marker-alt ss-ico"></i>
        <div>
            <span class="ss-label">Where?</span>
            <input type="text" name="city_match" class="ss-val" placeholder="Hotel Marina Bay" value="{{ request('city_match') }}" 
                   style="background: none; border: none; color: inherit; font: inherit; padding: 0; margin: 0; outline: none; width: 100%; position: relative; z-index: 5; pointer-events: auto;">
        </div>
    </div>
    <div class="ss-item">
        <i class="fas fa-calendar ss-ico"></i>
        <div>
            <span class="ss-label">When?</span>
            <input type="date" name="date_range" class="ss-val" 
                   min="{{ now()->format('Y-m-d') }}"
                   value="{{ request('date_range', now()->format('Y-m-d')) }}" 
                   style="background: none; border: none; color: inherit; font: inherit; padding: 0; margin: 0; outline: none; width: 100%; position: relative; z-index: 5; pointer-events: auto;">
        </div>
    </div>
    <div class="ss-item">
        <i class="fas fa-clock ss-ico"></i>
        <div>
            <span class="ss-label">What Time?</span>
            <input type="time" name="check_time" class="ss-val" value="{{ request('check_time', '20:00') }}" 
                   style="background: none; border: none; color: inherit; font: inherit; padding: 0; margin: 0; outline: none; width: 100%; position: relative; z-index: 5; pointer-events: auto;">
        </div>
    </div>
    <button type="submit" class="ss-go"><i class="fas fa-search"></i> Search</button>
</form>
            <div class="topbar-right">
                <a href="{{ route('index') }}" class="t-link">Home</a>
                <a href="{{ route('vendor.signup') }}" class="t-link list-hotel-top-link">List Hotel</a>
                <a href="{{ route('frontend.rooms') }}" class="t-link">← Results</a>
                @auth('web')
                <a href="{{ route('user.dashboard') }}">
                  <button class="t-btn"><i class="fas fa-user-circle" style="margin-right:5px"></i>My Account</button>
                </a>
                @else
                <a href="{{ route('user.login') }}">
                  <button class="t-btn">Login / Sign up</button>
                </a>
                @endauth
            </div>
        </div>
    </header>

    <div class="site-menu-backdrop" id="siteMenuBackdrop" onclick="closeSiteMenu()"></div>
    <aside class="site-mobile-menu" id="siteMobileMenu" aria-hidden="true">
        <div class="smm-head">
            <a href="{{ route('index') }}" class="smm-brand"><img src="{{ asset('stayzio/images/stayzio-logo.png') }}" alt="StayZio Logo" class="stayzio-brand-logo"><span class="stayzio-brand-text">Stay<span>Zio</span></span></a>
            <button type="button" onclick="closeSiteMenu()"><i class="fas fa-times"></i></button>
        </div>
        <a href="{{ route('index') }}"><i class="fas fa-home"></i> Home</a>
        <a href="{{ route('frontend.rooms') }}"><i class="fas fa-hotel"></i> Hotels</a>
        <a href="{{ route('vendor.signup') }}"><i class="fas fa-building"></i> List Hotel</a>
        @auth('web')
        <a href="{{ route('user.dashboard') }}"><i class="fas fa-user"></i> {{ Auth::guard('web')->user()->name }}</a>
        @else
        <a href="{{ route('user.login') }}"><i class="fas fa-user"></i> My Profile</a>
        @endauth
        <a href="#"><i class="fas fa-gift"></i> Offers</a>
        <a href="#"><i class="fas fa-headset"></i> Help & Support</a>
        @guest('web')
        <a href="{{ route('user.login') }}" class="smm-login"><i class="fas fa-sign-in-alt"></i> Login / Sign up</a>
        @endguest
    </aside>

    @yield('content')

@include('frontend.partials.footer')

  @includeIf('frontend.partials.popups')
  {{-- cookie alert --}}
  @if (!is_null($cookieAlertInfo) && $cookieAlertInfo->cookie_alert_status == 1)
    @include('cookie-consent::index')
  @endif

  @include('frontend.partials.scripts')
</body>

</html>